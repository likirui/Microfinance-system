<div class="content_center" style="margin-top:7em;">
	<img src="ico/mangoo_l.png" style="width:90%; max-width:530px;" />
</div>